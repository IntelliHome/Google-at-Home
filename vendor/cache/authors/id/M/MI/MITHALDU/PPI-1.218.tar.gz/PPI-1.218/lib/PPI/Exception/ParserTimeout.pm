package PPI::Exception::ParserTimeout;

use strict;
use PPI::Exception ();

use vars qw{$VERSION @ISA};
BEGIN {
	$VERSION = '1.218';
	@ISA     = 'PPI::Exception';
}

1;
