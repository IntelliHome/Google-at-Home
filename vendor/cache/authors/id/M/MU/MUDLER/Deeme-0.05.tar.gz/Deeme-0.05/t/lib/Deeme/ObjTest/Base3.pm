package Deeme::ObjTest::Base3;
use Deeme::ObjTest::Base1 -base;

has 'evil';


1;