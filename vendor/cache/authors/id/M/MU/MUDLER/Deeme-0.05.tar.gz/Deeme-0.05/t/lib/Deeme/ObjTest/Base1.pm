package Deeme::ObjTest::Base1;
use Deeme::Obj -base;

has 'bananas';

1;