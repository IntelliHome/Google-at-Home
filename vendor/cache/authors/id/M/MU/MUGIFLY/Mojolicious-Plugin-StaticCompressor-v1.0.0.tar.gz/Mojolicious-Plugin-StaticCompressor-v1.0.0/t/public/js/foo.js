/* test js file */
var foo = 1000;