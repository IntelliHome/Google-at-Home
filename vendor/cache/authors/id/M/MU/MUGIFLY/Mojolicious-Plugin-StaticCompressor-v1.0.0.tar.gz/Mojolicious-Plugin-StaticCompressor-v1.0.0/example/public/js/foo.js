/**
	Mojolicious::Plugin::StaticCompressor
	Example javascript file #1
**/

var foo = 'abcdefg';
alert('compressed');