/* test js file */
var bar = 'abcd';