/**
	Mojolicious::Plugin::StaticCompressor
	Example javascript file #2
**/

var bar = '1234567890';
alert('compressed...'+bar);