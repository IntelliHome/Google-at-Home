# Perl-Critic

The leading static analyzer for Perl.  Configurable, extensible, powerful.
