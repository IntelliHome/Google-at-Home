package BrokenModule;
use strict;
use warnings;

my $f = blorp;
1;
