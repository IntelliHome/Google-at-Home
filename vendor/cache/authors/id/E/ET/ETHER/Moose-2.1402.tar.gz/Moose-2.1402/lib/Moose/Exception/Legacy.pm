package Moose::Exception::Legacy;
$Moose::Exception::Legacy::VERSION = '2.1402';
use Moose;
extends 'Moose::Exception';

1;
