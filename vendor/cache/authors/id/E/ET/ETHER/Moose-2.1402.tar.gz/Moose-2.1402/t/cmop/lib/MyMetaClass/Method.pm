package MyMetaClass::Method;

use strict;
use warnings;

use parent 'Class::MOP::Method';

1;
