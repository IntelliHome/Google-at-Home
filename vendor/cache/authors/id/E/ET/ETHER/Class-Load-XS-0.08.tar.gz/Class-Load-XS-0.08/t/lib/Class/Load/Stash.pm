package Class::Load::Stash;
use strict;
use warnings;

sub a_method { 'a_method' }

1;
