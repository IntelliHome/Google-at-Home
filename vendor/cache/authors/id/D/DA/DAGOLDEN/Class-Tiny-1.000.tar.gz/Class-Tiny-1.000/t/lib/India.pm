use 5.006;
use strict;
use warnings;

package India;
use base 'Alfa';

use Class::Tiny qw/qux/;

1;
