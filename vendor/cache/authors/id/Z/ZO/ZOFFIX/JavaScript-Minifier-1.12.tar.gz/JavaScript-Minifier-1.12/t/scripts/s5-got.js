var x=foo
/2
/
2
/a/a;/regexp/
/regexp/;a+
++a;a-
--a;a
a;a3
.a