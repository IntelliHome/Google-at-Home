var x=1
/2
/
2
/a/a;2/2;/regexp/
/regexp/;a+ ++a;a- --a;a a;a3 .a