function (s) { alert("Foo"); }
