var x = 1/*a*/   

/ 2/*a*/  

/ /*a*/  

2/*a*/  

/a/a;/*a*/

2 /*a*/ / 2;

/regexp/ /*a*/

/regexp/;/*a*/
a +/*a*/++a;a -/*a*/--a;a/*a*/a;a3/*a*/.a