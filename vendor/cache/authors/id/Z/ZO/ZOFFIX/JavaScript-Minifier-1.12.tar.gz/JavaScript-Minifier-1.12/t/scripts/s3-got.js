var x=1//@a   
/2//@a  
/ //@a
2
/a/a;//@a
/regexp/ //@a
/regexp/;//@a
a+//@a 
++a;//@a
a-//@a 
--a;a//@a  
a;a3//@a
.a