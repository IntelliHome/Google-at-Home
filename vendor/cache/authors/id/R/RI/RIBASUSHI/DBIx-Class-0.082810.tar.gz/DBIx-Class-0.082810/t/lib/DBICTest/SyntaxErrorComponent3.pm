package DBICErrorTest::SyntaxError;

use strict;
use warnings;

I'm a syntax error!
