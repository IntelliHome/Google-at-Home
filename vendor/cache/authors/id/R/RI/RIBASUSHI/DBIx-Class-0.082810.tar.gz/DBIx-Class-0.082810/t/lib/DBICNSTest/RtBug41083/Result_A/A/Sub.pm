package DBICNSTest::RtBug41083::Result_A::A::Sub;
use strict;
use warnings;
use base 'DBICNSTest::RtBug41083::Result_A::A';
1;
