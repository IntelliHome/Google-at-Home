package DBICNSTest::Bogus::Bigos;

use warnings;
use strict;


1;
