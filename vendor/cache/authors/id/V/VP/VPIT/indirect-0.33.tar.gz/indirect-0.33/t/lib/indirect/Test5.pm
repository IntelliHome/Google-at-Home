no indirect ":fatal";
my $x;
if ($x) {
my $y = qq{abcdef
        @{[sort $x
 ->new]}
 };
}
1;
